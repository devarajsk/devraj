package coeassignment;

public class assignment8 
{
	public static void main(String[] args) {
		int fact=1,k=1;
		int num=5;
		while(k<=num)
		{
			fact=fact*k;
			k++;
		}
		System.out.println("factorial of "+num+ " is "+fact);
	}
	

}
